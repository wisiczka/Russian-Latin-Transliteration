import * as trans from './transliterate-main/index.js';

trans.transliterate('Fußgängerübergänge');
//=> 'Fussgaengeruebergaenge'

trans.transliterate('Я люблю единорогов');
//=> 'Ya lyublyu edinorogov'